x = int(input("Digite o valor correspondente ao lado de um quadrado: "))

perimetro = x * 4
area = x ** 2

print(f"perímetro: {perimetro} - área: {area}")
