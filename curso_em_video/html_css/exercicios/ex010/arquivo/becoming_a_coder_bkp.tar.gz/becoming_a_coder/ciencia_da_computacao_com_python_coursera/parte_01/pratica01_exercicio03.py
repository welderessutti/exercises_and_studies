x = int(input("Digite um número inteiro: "))

dezena = (x // 10) % 10

print(f"O dígito das dezenas é {dezena}")
