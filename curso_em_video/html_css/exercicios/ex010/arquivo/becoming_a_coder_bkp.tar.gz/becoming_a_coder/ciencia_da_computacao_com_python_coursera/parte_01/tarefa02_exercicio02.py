num = int(input("Digite um número: "))

if num % 3 == 0:
    print("Fizz")
else:
    print(num)
