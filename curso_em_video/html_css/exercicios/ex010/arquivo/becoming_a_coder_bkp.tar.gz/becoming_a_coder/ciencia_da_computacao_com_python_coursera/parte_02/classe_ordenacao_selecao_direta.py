class Ordenador:
    def selecao_direta(self, lista):
        fim = len(lista)
        for i in range(fim - 1):
            posicao_do_minimo = i
            for j in range(i + 1, fim):
                if lista[j] < lista[posicao_do_minimo]:
                    posicao_do_minimo = j
            lista[i], lista[posicao_do_minimo] = lista[posicao_do_minimo], lista[i]
        return lista


abc = [1, 25, 63, 4, 0, 88, 114, 153, 77, 11, 22, 95, 91, 12]

o = Ordenador()
print(abc)
print(o.selecao_direta(abc))
print(abc)
