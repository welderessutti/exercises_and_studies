num = int(input("Digite um número: "))

if num % 2 == 0:
    print("par")
else:
    print("ímpar")
