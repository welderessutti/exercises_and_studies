num = int(input("Digite um número: "))

if num % 5 == 0:
    print("Buzz")
else:
    print(num)
