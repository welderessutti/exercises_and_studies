cliente = input("Digite o nome do cliente: ")
dia = input("Digite o dia de vencimento: ")
mes = input("Digite o mês de vencimento: ")
fatura = input("Digite o valor da fatura: ")

print(f"Olá, {cliente}")
print(f"A sua fatura com vencimento em {dia} de {mes} no valor de R$ {fatura} está fechada.")
