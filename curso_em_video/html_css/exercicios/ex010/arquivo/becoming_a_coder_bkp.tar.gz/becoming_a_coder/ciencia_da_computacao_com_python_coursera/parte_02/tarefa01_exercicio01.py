def dimensoes(matriz):
    print(f"{len(matriz)}X{len(matriz[0])}")


minha_matriz = [[1], [2], [3]]
dimensoes(minha_matriz)
