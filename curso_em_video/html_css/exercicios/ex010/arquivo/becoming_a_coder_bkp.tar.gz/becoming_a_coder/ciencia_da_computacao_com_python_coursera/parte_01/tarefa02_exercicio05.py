num_1 = int(input("Digite um número: "))
num_2 = int(input("Digite um número: "))
num_3 = int(input("Digite um número: "))

if num_1 < num_2 < num_3:
    print("crescente")
else:
    print("não está em ordem crescente")
