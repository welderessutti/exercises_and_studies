def soma_elementos(lista):
    soma = 0
    for a in lista:
        soma += a
    return soma
