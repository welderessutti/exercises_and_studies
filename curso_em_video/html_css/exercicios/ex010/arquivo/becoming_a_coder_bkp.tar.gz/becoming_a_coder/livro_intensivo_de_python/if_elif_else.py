car = 'Bmw'

print(car == 'bmw')

lista = []

if lista:
    print('O "if" só será "True" se houver algum conteúdo dentro da lista.')
