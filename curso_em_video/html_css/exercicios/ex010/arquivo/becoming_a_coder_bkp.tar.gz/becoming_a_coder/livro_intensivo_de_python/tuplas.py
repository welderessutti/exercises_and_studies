foods = ('sushi', 'churrasco', 'pudim')

for food in foods:
    print(food)

foods = ('\npasta', 'purê', 'sorvete')
for food in foods:
    print(food)
