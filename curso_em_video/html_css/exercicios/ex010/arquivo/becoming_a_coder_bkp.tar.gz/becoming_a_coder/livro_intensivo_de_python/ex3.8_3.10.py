locais = [5, 8, 2, 0, 10, 9]

print(locais)

print(sorted(locais))

print(locais)

print(sorted(locais, reverse=True))

print(locais)

locais.reverse()

print(locais)

locais.reverse()

print(locais)

locais.sort()

print(locais)

locais.sort(reverse=True)

print(locais)
