pratos = ('Pizza', 'Macarrão', 'Lasanha', 'Churrasco', 'Sushi')


print('Cardápio original:')
for prato in pratos:
    print(prato)

pratos = ('Rosbife', 'Almondegas', 'Canapé', 'Paella', 'Feijoada')

print('\nCardápio modificado:')
for prato in pratos:
    print(prato)
