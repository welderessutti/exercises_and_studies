numbers = list(range(1, 6))
print(numbers)

squares = []
for value in range(1, 11):
    square = value ** 2
    squares.append(square)
print(squares)

cubo = []
for valor in range(1, 11):
    cubo.append(valor ** 3)
print(cubo)

abc = list(range(1, 10))
print(min(abc))
print(max(abc))
print(sum(abc))
