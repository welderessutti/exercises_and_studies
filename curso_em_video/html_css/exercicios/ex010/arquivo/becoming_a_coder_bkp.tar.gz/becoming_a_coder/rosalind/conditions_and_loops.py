soma = 0

for i in range(4260, 8560 + 1):
    if i % 2 == 1:
        soma += i

print(soma)
