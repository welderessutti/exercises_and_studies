print('\033[1;031;40mWelder\033[m \033[1;30;41mRessutti\033[m')
print('\033[1;030;41mWelder\033[m \033[1;91;40mRessutti\033[m')
print('\n\033[0;97;40mWelder\033[m \033[0;30;107mRessutti\033[m')
print('\033[7;97;40mWelder\033[m \033[7;30;107mRessutti\033[m')  # INVERTENDO AS CORES COM O "7"
print('\n\033[4;36;40mWelder\033[m \033[4;30;46mRessutti\033[m')
print('\033[4;30;46mWelder\033[m \033[4;36;40mRessutti\033[m')
