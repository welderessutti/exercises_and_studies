m = float(input('Digite a metragem: '))

cm = m * 100
mm = m * 1000

print(f'A medida em centímetros é {cm} cm e em milímetros é {mm} mm.')
