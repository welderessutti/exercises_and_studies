import pygame

pygame.init()

pygame.mixer.music.load(  # AQUI VEM O NOME DO ARQUIVO.MP3)
pygame.mixer.music.play()
    pygame.event.wait()
