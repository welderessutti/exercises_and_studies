nota1 = float(input('Digita a nota 1: '))
nota2 = float(input('Digite a nota 2: '))

media = (nota1 + nota2) / 2

print(f'A média do aluno é {media:.1f}')
