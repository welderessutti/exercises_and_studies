from ex_111_112 import moeda

p = 56

moeda.resumo(p)
