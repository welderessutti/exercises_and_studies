from ex_110 import moeda_resumo

p = float(input("Digite um valor: "))
moeda_resumo.resumo(p)
