nome = str(input('Digite seu nome: ')).strip()

print(f'Seu nome tem Silva? {"SILVA" in nome.upper()}')
