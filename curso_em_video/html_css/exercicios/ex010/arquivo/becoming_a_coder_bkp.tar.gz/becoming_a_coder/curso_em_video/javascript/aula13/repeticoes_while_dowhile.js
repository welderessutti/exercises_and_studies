var cont = 0
var cont_2 = 0

while (cont <= 10) {
    console.log(cont)
    cont++
}

do {
    console.log(cont_2)
    cont_2++
} while (cont_2 <= 10)
