x = float(input('Digite um número: '))

print(f'O seu antecessor é {x - 1} e seu sucessor é {x + 1}')
