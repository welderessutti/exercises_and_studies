nome = input('Digite seu nome: ')
print(f'Olá {nome:=^20}!', end=' ')
print(f'Olá {nome:=^20}!')
print('Olá', nome, '!', sep='/')
