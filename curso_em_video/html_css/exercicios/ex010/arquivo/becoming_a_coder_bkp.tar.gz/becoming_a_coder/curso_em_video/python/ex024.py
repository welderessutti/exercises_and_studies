cidade = str(input('Em qual cidade você nasceu? ')).strip()

print(cidade[:5].upper() == 'SANTO')
