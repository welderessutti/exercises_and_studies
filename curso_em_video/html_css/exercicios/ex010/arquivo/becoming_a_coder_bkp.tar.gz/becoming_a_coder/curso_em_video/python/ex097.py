def especial(msg):
    print("~" * (len(msg) + 4))
    print(f"  {msg}")
    print("~" * (len(msg) + 4))


especial("Olá, Mundo!")
