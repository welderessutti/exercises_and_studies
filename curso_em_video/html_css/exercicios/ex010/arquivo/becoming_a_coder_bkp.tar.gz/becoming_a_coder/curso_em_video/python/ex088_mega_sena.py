from random import randint
from time import sleep

lista = []

jogos = int(input('Quantos jogos você quer que eu sorteie?: '))

for c in range(0, jogos):
    lista.append([])
    cont = 0

    while cont < 6:
        sorteado = randint(1, 60)
        if sorteado not in lista[c]:
            lista[c].append(sorteado)
            cont += 1

    lista[c].sort()
    sleep(1)

    print(f'Jogo {c + 1}: {sorted(lista[c])}')

# PROFESSOR FEZ UM POUCO DIFERENTE, MAS NÃO COPIEI AQUI AINDA...
