var pais = "Brasil"

console.log(`Vivendo em ${pais}.`)

if (pais == "Brasil") {
    console.log("Você é Brasileiro!")
} else {
    console.log("Você é Estrangeiro!")
}
