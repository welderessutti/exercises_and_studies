import numpy as np

numeros = np.array([1., 3.5])
numeros += 3

print(numeros)
