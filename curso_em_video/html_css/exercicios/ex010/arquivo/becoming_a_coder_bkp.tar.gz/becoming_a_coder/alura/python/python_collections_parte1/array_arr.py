import array as arr

abc = arr.array("d", [1, 1.05])

print(abc)
