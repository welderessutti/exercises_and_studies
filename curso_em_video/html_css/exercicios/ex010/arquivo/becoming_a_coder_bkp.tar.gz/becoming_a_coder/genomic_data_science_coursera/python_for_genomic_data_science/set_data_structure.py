abc = {"welder", "welder", "welder"}
xyz = {"ressutti", "ressutti", "ressutti"}

print(abc | xyz)

splice_site_pairs = ['GT-AG', 'GC-AG', 'AT-AC']
print(splice_site_pairs[:-1])
