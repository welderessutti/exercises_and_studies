a = float(input('Digite um número para A: '))
b = float(input('Digite outro número para B: '))

b2 = ((a + b) - a)
a2 = ((b + a) - b)

print(f'O valor de A foi invertido para {b2}')
print(f'O valor de B foi invertido para {a2}')
