n = int(input('Digite um número: '))

if n < 0:
    n = n * -1

print(n)
