import math

num = float(input("Entre com um número: "))
raiz = math.sqrt(num)

print(f"\nA raiz quadrada de {num} é {raiz}")
