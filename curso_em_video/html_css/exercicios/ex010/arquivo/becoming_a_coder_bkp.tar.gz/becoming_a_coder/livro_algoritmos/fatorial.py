# USANDO LAÇO "FOR"
fat = 1

for fatorial in range(1, 6):
    fat = fat * fatorial
print(fat)

# USANDO LAÇO "WHILE"
fat_2 = 1
cont = 1

while cont <= 5:
    fat_2 = fat_2 * cont
    cont += 1
    print(cont)
print(fat_2)
