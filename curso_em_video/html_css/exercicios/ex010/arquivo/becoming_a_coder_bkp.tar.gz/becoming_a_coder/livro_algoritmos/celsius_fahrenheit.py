c = float(input("Digite a temperatura atual em graus Celcius: "))

f = 1.8 * c + 32

print(f"A temperatura em Fahrenheit é: {f} F°")
