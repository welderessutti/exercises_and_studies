for inteiro in range(15, 201):
    quadrado = inteiro ** 2
    print(quadrado)
