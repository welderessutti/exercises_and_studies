import funcoes_calculadora

funcoes_calculadora.main()
