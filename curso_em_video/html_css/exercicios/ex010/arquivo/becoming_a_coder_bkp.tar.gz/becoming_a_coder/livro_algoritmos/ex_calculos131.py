import math

# 01 _ f = raiz de 1/1*c - r²/4c²
c = 10
r = 5

f = math.sqrt(1/(1*c) - r**2/(4*(c**2)))
print(f)

# 02 _ x = a/b-c
a = 20
b = 15
c1 = 5

x = a/(b-c1)
print(x)

# 03 _ x = m*[a*h + v²/2]
m = 2
a1 = 4
h = 4
v = 4

x1 = m * (a1*h + (v**2/2))
print(x1)

# 04 _ d = v*t + a*t**2/2
v1 = 5
t = 2
a2 = 5

d = v1*t + ((a2*(t**2))/2)
print(d)

# 05 _ d = p-r / n
p = 80
r1 = 40
n = 2

d1 = (p-r1) / n
print(d1)

# 06 _ f = c*9/5 + 32
c1 = 50

f1 = c1*(9/5) + 32
print(f1)

# 07 _ c = (f-32) * 5/9
f2 = 32

c2 = (f2-32) * (5/9)
print(c2)
