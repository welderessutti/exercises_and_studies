a = []

for c in range(0, 10):
    a.append(input('Digite um nome: '))

print(a)
