fatorial = 1

for fat in range(1, 11):
    if fat % 2 == 1:
        fatorial = fat * fatorial
print(fatorial)
