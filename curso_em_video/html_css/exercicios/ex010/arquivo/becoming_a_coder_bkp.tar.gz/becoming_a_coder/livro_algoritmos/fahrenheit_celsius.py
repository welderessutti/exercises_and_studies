f = float(input("Digite a temperatura atual em graus Fahrenheit: "))

c = (f - 32) / 1.8

print(f"A temperatura em graus Celsius é: {c} C°")
