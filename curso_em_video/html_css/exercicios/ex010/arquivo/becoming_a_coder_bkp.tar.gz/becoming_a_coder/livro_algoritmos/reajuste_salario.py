s = float(input('Digite o salário: '))
r = float(input('Digite o reajuste: '))

ns = s + (r/100 * s)

print(ns)
