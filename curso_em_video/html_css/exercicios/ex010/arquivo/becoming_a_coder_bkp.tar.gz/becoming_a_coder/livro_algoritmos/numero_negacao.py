num = int(input('Digite o número: '))

if not num > 3:
    print(num)
