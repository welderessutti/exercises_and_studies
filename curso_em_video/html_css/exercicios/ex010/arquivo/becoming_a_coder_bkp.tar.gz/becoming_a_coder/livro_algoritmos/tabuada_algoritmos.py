tabuada = int(input('Qual tabuada?: '))

for tabuada_1 in range(1, 11):
    print(f'{tabuada} x {tabuada_1} = {tabuada * tabuada_1}')
