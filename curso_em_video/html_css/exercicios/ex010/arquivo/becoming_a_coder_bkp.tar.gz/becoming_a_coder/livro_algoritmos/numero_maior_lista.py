a = int(input('A: '))
b = int(input('B: '))
c = int(input('C: '))
d = int(input('D: '))
e = int(input('E: '))

lista = sorted([a, b, c, d, e])

print(f'O número maior é o {lista[-1]} e o menor número é o {lista[0]}')
