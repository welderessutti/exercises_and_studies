r = 5
altura = 30

volume = 3.14159 * r**2 * altura
print(volume)
