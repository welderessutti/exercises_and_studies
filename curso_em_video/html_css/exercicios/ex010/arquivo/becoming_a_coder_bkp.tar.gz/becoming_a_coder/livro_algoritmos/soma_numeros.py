a = int(input("Digite um número: "))
b = int(input("Digite outro número: "))

x = a + b

print(f"\nA soma dos dois números é igual a: {x}.")
