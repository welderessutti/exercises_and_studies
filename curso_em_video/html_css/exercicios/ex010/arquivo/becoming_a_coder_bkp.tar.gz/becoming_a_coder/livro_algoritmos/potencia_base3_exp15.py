cont = 0

while cont <= 15:
    exp = 3 ** cont
    cont += 1
    print(exp)
