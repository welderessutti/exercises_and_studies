a = int(input('Digite uma valor para A: '))
b = int(input('Digite uma valor para B: '))

x = (a-b)**2

print(f'O resultado do quadrado da difernte entre A e B é: {x}')
