soma = 0
cont = 0

for naturais in range(1, 101):
    soma = soma + naturais
    cont += 1

print(soma)
print(cont)
