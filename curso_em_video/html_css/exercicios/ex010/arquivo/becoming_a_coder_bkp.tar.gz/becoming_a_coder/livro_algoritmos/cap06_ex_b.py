a = []
b = []

for c in range(0, 8):
    a.append(int(input('Digite um número: ')))
    b.append(a[c] * 3)

print(a)
print(b)
