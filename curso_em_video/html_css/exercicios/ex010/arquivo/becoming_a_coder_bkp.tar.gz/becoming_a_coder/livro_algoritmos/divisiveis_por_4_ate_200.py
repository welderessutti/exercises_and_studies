cont = 1

while cont <= 200:
    if cont % 4 == 0:
        print(cont)
    cont += 1
