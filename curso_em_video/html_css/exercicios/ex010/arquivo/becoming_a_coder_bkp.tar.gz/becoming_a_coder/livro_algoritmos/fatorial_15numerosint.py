n1 = int(input('Número 1: '))
n2 = int(input('Número 2: '))
n3 = int(input('Número 3: '))
n4 = int(input('Número 4: '))
n5 = int(input('Número 5: '))
n6 = int(input('Número 6: '))
n7 = int(input('Número 7: '))
n8 = int(input('Número 8: '))
n9 = int(input('Número 9: '))
n10 = int(input('Número 10: '))
n11 = int(input('Número 11: '))
n12 = int(input('Número 12: '))
n13 = int(input('Número 13: '))
n14 = int(input('Número 14: '))
n15 = int(input('Número 15: '))

fat = 1
cont = 1

while cont <= n1:
    fat = fat * cont
    cont += 1
print(fat)

fat2 = 1
cont2 = 1

while cont2 <= n2:
    fat2 = fat2 * cont2
    cont2 += 1
print(fat2)

fat3 = 1
cont3 = 1

while cont3 <= n3:
    fat3 = fat3 * cont3
    cont3 += 1
print(fat3)

fat4 = 1
cont4 = 1

while cont4 <= n4:
    fat4 = fat4 * cont4
    cont4 += 1
print(fat4)

fat5 = 1
cont5 = 1

while cont5 <= n5:
    fat5 = fat5 * cont5
    cont5 += 1
print(fat5)

fat6 = 1
cont6 = 1

while cont6 <= n6:
    fat6 = fat6 * cont6
    cont6 += 1
print(fat6)

fat7 = 1
cont7 = 1

while cont7 <= n7:
    fat7 = fat7 * cont7
    cont7 += 1
print(fat7)

fat8 = 1
cont8 = 1

while cont8 <= n8:
    fat8 = fat8 * cont8
    cont8 += 1
print(fat8)

fat9 = 1
cont9 = 1

while cont9 <= n9:
    fat9 = fat9 * cont9
    cont9 += 1
print(fat9)

fat10 = 1
cont10 = 1

while cont10 <= n10:
    fat10 = fat10 * cont10
    cont10 += 1
print(fat10)

fat11 = 1
cont11 = 1

while cont11 <= n11:
    fat11 = fat11 * cont11
    cont11 += 1
print(fat11)

fat12 = 1
cont12 = 1

while cont12 <= n12:
    fat12 = fat12 * cont12
    cont12 += 1
print(fat12)

fat13 = 1
cont13 = 1

while cont13 <= n13:
    fat13 = fat13 * cont13
    cont13 += 1
print(fat13)

fat14 = 1
cont14 = 1

while cont14 <= n14:
    fat14 = fat14 * cont14
    cont14 += 1
print(fat14)

fat15 = 1
cont15 = 1

while cont15 <= n15:
    fat15 = fat15 * cont15
    cont15 += 1
print(fat15)
print(cont15)
