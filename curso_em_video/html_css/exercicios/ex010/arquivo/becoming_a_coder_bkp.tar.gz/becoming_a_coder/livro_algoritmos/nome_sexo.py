nome = input("Digite o seu nome: ")
sexo = input("Digite o seu sexo: ")
idade = input("Digite sua idade: ")

print(f"\nO nome do paciente é {nome}, seu sexo é {sexo} e tem {idade} anos.")

