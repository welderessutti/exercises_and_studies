print(f"Hello, World!")
