a = int(input("A: "))
b = int(input("B: "))
c = int(input("C: "))
d = int(input("D: "))

if a % 2 == 0 or a % 3 == 0:
    print(a)
if b % 2 == 0 or a % 3 == 0:
    print(b)
if c % 2 == 0 or c % 3 == 0:
    print(c)
if d % 2 == 0 or d % 3 == 0:
    print(d)
