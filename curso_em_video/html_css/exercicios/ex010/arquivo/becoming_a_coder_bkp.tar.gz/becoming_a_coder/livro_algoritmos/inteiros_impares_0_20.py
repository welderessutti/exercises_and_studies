for impares in range(0, 21):
    if impares % 2 != 0:
        print(impares)
