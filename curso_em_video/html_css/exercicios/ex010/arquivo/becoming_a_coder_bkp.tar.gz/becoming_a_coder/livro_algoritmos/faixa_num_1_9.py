num = int(input('Digite um número de 1 até 9: '))

if num >= 1 and num <= 9:
    print(f'O número {num} está na faixa permitida.')
else:
    print(f'O número {num} está fora da faixa permitida.')
