x = int(input('Digite um número: '))

print(x**2)
