a = 10
b = 5.0
c = '10'
d = a == 10

print(type(a))
print(type(b))
print(type(c))
print(type(d))
