a = 'cachorro'
b = 'gato'
c = 'macaco'

print('',a, b, c, sep='/')
print(a, b, c, sep=' -> ')
print(a, b, c, sep=' == ')
