a = []
b = []

for x in range(0, 15):
    a.append(int(input('Digite um número: ')))
    b.append(a[x] ** 2)

print(a)
print(b)
