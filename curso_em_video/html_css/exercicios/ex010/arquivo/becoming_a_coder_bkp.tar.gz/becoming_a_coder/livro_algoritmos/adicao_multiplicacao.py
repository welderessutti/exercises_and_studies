a = int(input('Digite um valor para A: '))
b = int(input('Digite um valor para B: '))
c = int(input('Digite um valor para C: '))
d = int(input('Digite um valor para D: '))

ab = a + b
aabb = a * b
ac = a + c
aacc = a * c
ad = a + d
aadd = a * d
bc = b + c
bbcc = b * c
bd = b + d
bbdd = b * d
cd = c + d
ccdd = c * d

print(ab, aabb, ac, aacc, ad, aadd, bc, bbcc, bd, bbdd, cd, ccdd)
