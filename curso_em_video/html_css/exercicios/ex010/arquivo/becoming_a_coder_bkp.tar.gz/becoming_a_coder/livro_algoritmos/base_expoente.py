a = int(input('Digite um número para base: '))
b = int(input('Digite um número para expoente: '))

x = a**b

print(x)
