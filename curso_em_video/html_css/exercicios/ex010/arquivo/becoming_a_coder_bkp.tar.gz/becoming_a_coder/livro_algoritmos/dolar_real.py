d = float(input('Quantidade de dólares: '))
c = float(input('Cotação do dólar: '))

r = d*c

print(r)
