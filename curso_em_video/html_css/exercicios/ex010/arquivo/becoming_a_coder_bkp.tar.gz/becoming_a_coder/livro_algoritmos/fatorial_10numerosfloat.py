n1 = float(input('Número 1: '))
n2 = float(input('Número 2: '))
n3 = float(input('Número 3: '))
n4 = float(input('Número 4: '))
n5 = float(input('Número 5: '))
n6 = float(input('Número 6: '))
n7 = float(input('Número 7: '))
n8 = float(input('Número 8: '))
n9 = float(input('Número 9: '))
n10 = float(input('Número 10: '))

fat1 = 1

for fatorial in range(1, int(n1) + 1):
    fat1 = fatorial * fat1
print(fat1)

fat2 = 1

for fatorial in range(1, int(n2) + 1):
    fat2 = fatorial * fat2
print(fat2)

fat3 = 1

for fatorial in range(1, int(n3) + 1):
    fat3 = fatorial * fat3
print(fat3)

fat4 = 1

for fatorial in range(1, int(n4) + 1):
    fat4 = fatorial * fat4
print(fat4)

fat5 = 1

for fatorial in range(1, int(n5) + 1):
    fat5 = fatorial * fat5
print(fat5)

fat6 = 1

for fatorial in range(1, int(n6) + 1):
    fat6 = fatorial * fat6
print(fat6)

fat7 = 1

for fatorial in range(1, int(n7) + 1):
    fat7 = fatorial * fat7
print(fat7)

fat8 = 1

for fatorial in range(1, int(n8) + 1):
    fat8 = fatorial * fat8
print(fat8)

fat9 = 1

for fatorial in range(1, int(n9) + 1):
    fat9 = fatorial * fat9
print(fat9)

fat10 = 1

for fatorial in range(1, int(n10) + 1):
    fat10 = fatorial * fat10
print(fat10)

print(f'Soma = {fat1 + fat2 + fat3 + fat4 + fat5 + fat6 + fat7 + fat8 + fat9 + fat10}')
print(f'Média = {(fat1 + fat2 + fat3 + fat4 + fat5 + fat6 + fat7 + fat8 + fat9 + fat10) / 10}')
