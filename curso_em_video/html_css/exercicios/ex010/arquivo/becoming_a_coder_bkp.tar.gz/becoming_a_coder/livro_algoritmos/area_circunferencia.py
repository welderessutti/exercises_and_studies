# a = pi.r^2

r = float(input("Raio: "))
pi = 3.14159265

a = pi * (r**2)

print(f"A área da circunferência é de: {a} m2.")
